package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Dbconnection {
   public static Connection takeConnection() {
	   Connection con = null;
	   try {
		   Class.forName("com.mysql.cj.jdbc.Driver");
		   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Deepanshu1608");
	   }
	   catch(Exception e) {
		   e.printStackTrace();
	   }
	   return con;
   }
   public static int insertRequest(String title, String description , String name , String yourdepart , 
		   String targetdepart , String date) {
	   int status =0;
	   try {
		Connection con = takeConnection();
		String query = "insert into request(title,description,raised_by,department,target_department,Request_date_time) values(?,?,?,?,?,?)";
		   PreparedStatement ps = con.prepareStatement(query);
		   ps.setString(1,title);
		   ps.setString(2,description);
		   ps.setString(3,name);
		   ps.setString(4,yourdepart);
		   ps.setString(5,targetdepart);
		   ps.setString(6,date);
		  status =  ps.executeUpdate();
	   }
	   catch(Exception e) {
		   e.printStackTrace();
		   
	   } 
	   return status;
   }
   
}
